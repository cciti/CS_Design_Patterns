﻿
/// <summary>
/// Data type class to store information for a single course
/// </summary>
public class Course
{
    public string courseName { get; set; }
    public int hours { get; set; }

	public Course()
	{
	}

}