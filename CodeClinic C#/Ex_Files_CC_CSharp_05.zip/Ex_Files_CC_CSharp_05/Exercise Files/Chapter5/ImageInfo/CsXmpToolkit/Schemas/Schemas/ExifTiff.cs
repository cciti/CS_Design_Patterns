using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// EXIF Schema for TIFF Properties
	/// </summary>
	public sealed class ExifTiff
	{
	}
}