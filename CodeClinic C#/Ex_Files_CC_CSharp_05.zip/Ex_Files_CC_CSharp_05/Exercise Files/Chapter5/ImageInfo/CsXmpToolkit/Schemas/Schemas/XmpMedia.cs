using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// XMP Media Management Schema
	/// </summary>
	public sealed class XmpMedia
	{
	}
}
