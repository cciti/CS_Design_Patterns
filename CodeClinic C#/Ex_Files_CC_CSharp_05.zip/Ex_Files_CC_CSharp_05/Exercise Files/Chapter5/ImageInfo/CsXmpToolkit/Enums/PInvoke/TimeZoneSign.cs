using System;

namespace SE.Halligang.CsXmpToolkit.PInvoke
{
	internal enum TimeZoneSign : int
	{
		WestOfUtc	= -1,
		IsUtc		= 0,
		EastOfUtc	= 1,
	}
}
