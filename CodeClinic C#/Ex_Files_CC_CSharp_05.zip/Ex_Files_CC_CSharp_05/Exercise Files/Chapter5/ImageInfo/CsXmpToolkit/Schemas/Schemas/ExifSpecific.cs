using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// EXIF Schema for EXIF-specific Properties
	/// </summary>
	public sealed class ExifSpecific
	{
	}
}