using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// XMP Dynamic Media Schema
	/// </summary>
	public sealed class XmpDynamic
	{
	}
}
