using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// XMP Paged-Text Schema
	/// </summary>
	public sealed class XmpText
	{
	}
}
