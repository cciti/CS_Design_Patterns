using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	/// <summary>
	/// Camera Raw Schema
	/// </summary>
	public sealed class Raw
	{
	}
}
