using System;
using System.Collections.Generic;
using System.Text;

namespace SE.Halligang.CsXmpToolkit.Schemas
{
	public enum ShapeType
	{
		Rectangle,
		Circle,
		Polygon,
	}
}
